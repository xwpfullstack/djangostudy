安装
=================

自动安装
-----------------

可以通过 pip 进行安装::

    pip install wechat-sdk

也可以通过 easy_install 进行安装::

    easy_install wechat-sdk

手动安装
-----------------

在终端下输入下列命令::

    wget https://github.com/doraemonext/wechat-python-sdk/archive/master.tar.gz
    tar zvxf master.tar.gz
    cd wechat-python-sdk-master
    python setup.py build
    python setup.py install