# -*- coding: utf-8 -*-

from django.apps import AppConfig


class ContextConfig(AppConfig):
    name = 'wechat_sdk.context.framework.django'
    label = 'wechat_sdk_django'
    verbose_name = 'WechatDjango'