#encoding=utf-8
WEIXIN_TOKEN = 'itcastcpp'
WEIXIN_APPID = 'wx52ec202e3a194f02'
WEIXIN_APPSECRET = '28f3f9561851c3bd4eb56546d4642f81'

WEIXIN_ACCESS_TOKEN_URL = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' + WEIXIN_APPID + '&secret=' + WEIXIN_APPSECRET
WEIXIN_MCH_ID = '12345678'
WEIXIN_API_KEY = 'abcdefghijklmnabcdefghijklmn1234'
WEIXIN_PAY_NOTIFY_URL = 'http://www.itcastcpp.cn/wangteng/pay_notify/'

# 为方便demo，下面是临时设置
CREATE_MENU_URL = 'http://www.xingwenpeng.com/itcastcpp/wxbase/userinfo/'
