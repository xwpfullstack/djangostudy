from django.contrib import admin
from fruit.models import *

# Register your models here.
admin.site.register(Person)
admin.site.register(Case)
admin.site.register(Goods)
admin.site.register(Indent)
